# diffdf 1.0.4

- No new functionality
- Update to make package compatible with tibble 3.0.0

# diffdf 1.0.3

- No new functionality
- Update to make package compatible with the changes made to sampling within core R

# diffdf 1.0.2

- No new functionality
- Update to make package compatible with tibble 2.0.0

# diffdf 1.0.1

- Added package down site  
- Updated description file to include unnamed dependencies in test files
- Added Travis 
- Added CodeCov

# diffdf 1.0.0 

- Initial Release !!