## Release summary
In this version I have:
- Updated the package to fix errors introduced by the most recent version of tibble (2.99.99.9014 which will become 3.0.0 upon release) 
- Updated my email in the maintainers list from craig.gower@roche.com to craig.gower-page@roche.com as I have changed my name after getting married and work updated my email address. I no longer have access or the ability to send emails from the old email address however emails to the old email address are forwarded to the new one (that is if you wish to confirm this change). 

## Test environments
- local Mac OS Mojave R 3.6.2
- Windows Server 2008 R2 SP1, R-devel, 32/64 bit (Rhub)
- Debian Linux, R-release, GCC (Rhub)

## R CMD check results
R CMD check results
0 errors | 0 warnings | 0 notes

## Downstream dependencies
There are currently no downstream dependencies for this package