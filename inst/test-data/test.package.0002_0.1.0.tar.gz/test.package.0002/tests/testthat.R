library(testthat)
library(test.package.0002)

test_check("test.package.0002")
