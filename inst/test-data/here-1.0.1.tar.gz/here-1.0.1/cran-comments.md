here 1.0.1: Compatibility with testthat 3.0.1

## Cran Repository Policy

- [x] Reviewed CRP last edited 2020-10-29.

## R CMD check results

- [x] Checked locally, R 4.0.3
- [x] Checked on CI system, R 4.0.3
- [x] Checked on win-builder, R devel

## Current CRAN check results

- [x] Checked on 2020-12-13, no problems found.
