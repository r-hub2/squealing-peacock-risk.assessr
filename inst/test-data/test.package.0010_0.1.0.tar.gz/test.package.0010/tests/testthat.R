library(testthat)
library(test.package.0010)

test_check("test.package.0010")
