test_that("addOne works correctly", {
  expect_equal(addOne(1), 2)
  expect_equal(addOne(0), 1)
  expect_equal(addOne(-1), 0)
  expect_equal(addOne(100), 101)
})
