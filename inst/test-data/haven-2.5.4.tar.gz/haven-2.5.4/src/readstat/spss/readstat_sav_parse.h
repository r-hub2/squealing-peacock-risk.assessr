//
//  sav_parse.h
//

readstat_error_t sav_parse_long_variable_names_record(void *data, int count, sav_ctx_t *ctx);
readstat_error_t sav_parse_very_long_string_record(void *data, int count, sav_ctx_t *ctx);

