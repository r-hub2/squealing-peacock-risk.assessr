testthat::test_that('this works', {
  df <- data.frame(x = 1:4, y = 1:4)

  filtered_y <- filter_first_two_rows_y(df)

  testthat::expect_identical(length(filtered_y), 1L)

  testthat::expect_true(checkmate::check_class(filtered_y, "data.frame"))
})
