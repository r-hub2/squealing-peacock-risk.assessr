library(testthat)
library(test.package.0003)

test_check("test.package.0003")
