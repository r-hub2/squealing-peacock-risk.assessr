testthat::test_that('this works', {
  testthat::expect_equal(myfunction(1), 3)
  })
