#' Adds 1 to x
#' @param x a number
#' @export
myfunction <- function(x) {
  checkmate::assert_numeric(x)
  x + 1
}
