## R CMD check results

0 errors | 0 warnings | 0 note

## revdepcheck results

This is a patch release that mostly contains documentation improvements; I did not check revdeps.
