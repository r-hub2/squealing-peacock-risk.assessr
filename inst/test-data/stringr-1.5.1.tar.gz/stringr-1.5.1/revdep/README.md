# Revdeps

## Failed to check (24)

|package       |version |error |warning |note |
|:-------------|:-------|:-----|:-------|:----|
|admiral       |0.8.4   |1     |        |     |
|admiralonco   |0.1.0   |1     |        |     |
|NA            |?       |      |        |     |
|NA            |?       |      |        |     |
|NA            |?       |      |        |     |
|NA            |?       |      |        |     |
|NA            |?       |      |        |     |
|genekitr      |?       |      |        |     |
|ggPMX         |?       |      |        |     |
|NA            |?       |      |        |     |
|NA            |?       |      |        |     |
|NA            |?       |      |        |     |
|MARVEL        |?       |      |        |     |
|numbat        |?       |      |        |     |
|OlinkAnalyze  |?       |      |        |     |
|Platypus      |?       |      |        |     |
|RVA           |?       |      |        |     |
|NA            |?       |      |        |     |
|NA            |?       |      |        |     |
|tidySEM       |?       |      |        |     |
|NA            |?       |      |        |     |
|tinyarray     |?       |      |        |     |
|NA            |?       |      |        |     |
|xpose.nlmixr2 |?       |      |        |     |

## New problems (12)

|package       |version  |error  |warning |note |
|:-------------|:--------|:------|:-------|:----|
|[cmcR](problems.md#cmcr)|0.1.9    |__+1__ |        |     |
|[crispRdesignR](problems.md#crisprdesignr)|1.1.6    |__+1__ |        |2    |
|[cspp](problems.md#cspp)|0.3.2    |__+1__ |__+1__  |     |
|[flair](problems.md#flair)|0.0.2    |__+2__ |__+1__  |2    |
|[GetLattesData](problems.md#getlattesdata)|1.4.1    |__+2__ |__+1__  |     |
|[glmmPen](problems.md#glmmpen)|1.5.1.10 |__+1__ |        |2    |
|[mpwR](problems.md#mpwr)|0.1.0    |__+2__ |__+1__  |     |
|[postpack](problems.md#postpack)|0.5.3    |__+1__ |__+1__  |1    |
|[repr](problems.md#repr)|1.1.4    |__+1__ |        |2    |
|[tidyfst](problems.md#tidyfst)|1.7.5    |__+1__ |        |1    |
|[tidyft](problems.md#tidyft)|0.4.5    |__+1__ |        |2    |
|[zipangu](problems.md#zipangu)|0.3.1    |__+2__ |        |1    |

