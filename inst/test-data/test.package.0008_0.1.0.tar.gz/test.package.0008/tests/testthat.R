library(testthat)
library(test.package.0001)

test_check("test.package.0001")
